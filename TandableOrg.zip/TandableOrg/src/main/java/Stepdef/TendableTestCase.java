package Stepdef;

import Pages.TendableWebPage;
import cucumber.api.java8.En;
import io.cucumber.datatable.DataTable;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class TendableTestCase implements En {
        public TendableTestCase() {
            SoftAssert softAssert = new SoftAssert();

            Given("User Launch the URL {string}", (String url) -> {
                new TendableWebPage().launchURL(url);
            });

            And("User lands on Home page", () -> {
                new TendableWebPage().checkHomePageLoaded();
            });

            And("User verifies {string} on each tab selection", (String requestDemoOption) -> {
                softAssert.assertEquals(requestDemoOption,new TendableWebPage().getTabOptions(),"Given options are not present ");
                softAssert.assertTrue(new TendableWebPage().checkReQuestDemoButtonPresent(),"Request Demo button not present ");
            });

            And("User navigate to Contact Us page", () -> {
                new TendableWebPage().navigateToContactUsPage();
            });

            And("User select Marketing page", () -> {
                new TendableWebPage().navigateToMarketingPage("Marketing");
            });

            And("User fills the Marketing Form as below", (DataTable dataTable) -> {
                List<String> expectedData = dataTable.asList(String.class);
                new TendableWebPage().fillMarketingForm(expectedData);
            });

            And("User agrees the consent", () -> {
                new TendableWebPage().clickAgreeConsentButton();
            });
            When("User submit the form", () -> {
                new TendableWebPage().clickSubmitButton();
            });
            Then("An error message should appear as {string}", (String message) -> {
                softAssert.assertEquals("It should not allow to submit the form without entering the message text",message,new TendableWebPage().getErrorMessage());
            });
        }

}
