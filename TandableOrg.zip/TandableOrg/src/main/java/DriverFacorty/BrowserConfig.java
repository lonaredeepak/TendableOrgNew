package DriverFacorty;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class BrowserConfig
{
    public static ThreadLocal<WebDriver> drivers = new ThreadLocal<>();

    public WebDriver initDriver() {
        WebDriver driver = drivers.get();
        System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
        driver = new ChromeDriver();
        return driver;
    }
}
