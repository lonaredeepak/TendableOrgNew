package Pages;


import DriverFacorty.BrowserConfig;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.List;

public class TendableWebPage {

    WebDriver driver =new BrowserConfig().initDriver(); ;
    WebDriverWait wait =new WebDriverWait(driver,10);;

    public static final String MAIN_MENU_OPTIONS = "nav[id='main-navigation-new'] li a";
    public static final String REQUEST_DEMO_BUTTON = "//a[@class='button ' and contains(text(),'Request A Demo')]";
    public static final String CONTACT_US_BUTTON = "//a[@class='button inverted' and contains(text(),'Contact Us')]";
    public static final String CONTACT_US_PAGE_OPTIONS = "div[class='text-center'] div";
    public static final String FULL_NAME_BOX = "input[id='form-input-fullName']";
    public static final String ORG_NAME_BOX = "input[id='form-input-organisationName']";
    public static final String PHONE_BOX = "input[id='form-input-cellPhone']";
    public static final String EMAIL_BOX = "input[id='form-input-email']";
    public static final String AGREE_CONSENT_BUTTON = "input[id='form-input-consentAgreed-0']";
    public static final String SUBMIT_BUTTON = "button[name='form_page_submit']";
    public static final String ERROR_MESSAGE = "div[class='ff-form-errors'] p";


    public void launchURL(String url) {
        driver.navigate().to(url);
        wait.until(ExpectedConditions.visibilityOfElementLocated(new By.ByCssSelector(MAIN_MENU_OPTIONS)));
        driver.manage().window().maximize();
    }

    public boolean checkHomePageLoaded() {
        if (driver.findElement(new By.ByCssSelector(MAIN_MENU_OPTIONS)).isDisplayed()) {
            return true;
        }
        return false;
    }

    public List<WebElement> getTabOptions() {
        List<WebElement> list = driver.findElements(new By.ByCssSelector(MAIN_MENU_OPTIONS));
        return list;
    }

    public boolean checkReQuestDemoButtonPresent() {
        List<WebElement> list = driver.findElements(new By.ByCssSelector(MAIN_MENU_OPTIONS));
        for (WebElement element : list) {
            element.click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(new By.ByCssSelector(REQUEST_DEMO_BUTTON)));
            if (driver.findElement(new By.ByCssSelector(REQUEST_DEMO_BUTTON)).isDisplayed()) {
                return true;
            }
        }
        return false;
    }

    public void navigateToContactUsPage()
    {
        driver.findElement(By.cssSelector(CONTACT_US_BUTTON)).click();
    }

    public void navigateToMarketingPage(String pageName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(new By.ByCssSelector(REQUEST_DEMO_BUTTON)));
        List<WebElement> options = driver.findElements(By.cssSelector(CONTACT_US_PAGE_OPTIONS));
        for (WebElement element : options) {
            if (element.getText().equals(pageName)) {
                element.findElement(new By.ByTagName("button")).click();
            }
        }
    }

    public void fillMarketingForm(List<String> data)
    {
        data.forEach(textFields -> {
//        driver.findElement(new By.ByCssSelector(FULL_NAME_BOX)).sendKeys(textFields.fullName);
//            driver.findElement(new By.ByCssSelector(ORG_NAME_BOX)).sendKeys(textFields.OrgName);
//            driver.findElement(new By.ByCssSelector(PHONE_BOX)).sendKeys(textFields.phone);
//            driver.findElement(new By.ByCssSelector(EMAIL_BOX)).sendKeys(textFields.email);

        });
    }

    public void clickAgreeConsentButton()
    {
        driver.findElement(new By.ByCssSelector(AGREE_CONSENT_BUTTON)).click();
    }

    public void clickSubmitButton()
    {
        driver.findElement(new By.ByCssSelector(SUBMIT_BUTTON)).click();
    }

    public String getErrorMessage()
    {
        return driver.findElement(new By.ByCssSelector(ERROR_MESSAGE)).getText();
    }

}
